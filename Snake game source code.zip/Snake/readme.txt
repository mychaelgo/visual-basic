Title: [ * * * The Ultimate Snake * * * ]
Description: This game fo snake is different from many others. In addition to the classic snake game,
this game ships many new features such as 2 modes: classic and campaign,where in campaign mode
you can progress through different levels by eating food and avoid being hit in the walls or
on your own body.According to me, the most novel idea in the game is theat it supports a two 
player option in both the modes. The players can compete through various levels of exciting gameplay
for hours. Initially, there are 7 levels in the campaign modes, but the the game is so stuctured that 
almost anyone can add new levels to the game. If so, please mail me the code for those levels.
If you like the game, please encourge me by giving your valuable votes.


This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=58604&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.

please contact : 
http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=58604&lngWId=1
www.cybervels.co.cc
www.friendster.com/velsvels
