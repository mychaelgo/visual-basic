Title: b8 SIM - Sales and Inventory Manager
Description: A simple application that can support purchasing, sales and automated inventory management. I earned a lot from PSCODE.com that is why I want to share this piece of code to all beginners and for those who want to learn VB6. It includes 16 user controls and a modified LynxGrid control which originally created by Richard Mewett (Thanks a lot bro).
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=66681&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
