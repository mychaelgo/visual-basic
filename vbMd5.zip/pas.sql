-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Waktu pembuatan: 08. Nopember 2008 jam 01:50
-- Versi Server: 5.0.45
-- Versi PHP: 5.2.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `pas`
-- 

-- --------------------------------------------------------

-- 
-- Struktur dari tabel `ijin`
-- 

CREATE TABLE `ijin` (
  `nama` varchar(15) collate latin1_general_ci NOT NULL,
  `pass` varchar(100) collate latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- 
-- Dumping data untuk tabel `ijin`
-- 

INSERT INTO `ijin` (`nama`, `pass`) VALUES 
('andriy', '19b68cc2fb667f2bd2a83c88979ee2cb'),
('maman', '6ffee7d3af984c95d72d813efda2d919'),
('ari', 'fc292bd7df071858c2d0f955545673c1'),
('magun', '5e2dda297f23a7ee743888cfc3940506'),
('tajam', '2e7e46705fdebdf955f69227705b7ec47e74a164'),
('huri', '1a2c78fcf8624746d9e806e05f7f6f24d3901aa8'),
('test', '098f6bcd4621d373cade4e832627b4f6');
