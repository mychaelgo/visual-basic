Install Activereport terlebih dahulu

user : admin
pass : 1234

http://www.varid-id.co.cc


                        ii      dd       ii      dd
                                dd               dd 
vv  vv   aaaa   r rrrr  ii      dd       ii      dd
vv  vv      aa  rrrrrr  ii  dddddd       ii  dddddd
vv  vv  aaaaaa  rr      ii  dd  dd  ===  ii  dd  dd  
 vvvv   aa  aa  rr      ii  dd  dd       ii  dd  dd
  vv    aaaaaa  rr      ii  dddddd       ii  dddddd 