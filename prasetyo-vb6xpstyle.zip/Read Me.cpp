
 File Supplement e-Book :

 Visual Basic 6.0
 Menggunakan XP Style

 Penulis :   Prasetyo Priadi
 office  :   www.PrasetyoLabs.co.cc

 Free e-Learning :

    www.IlmuKomputer.Org


 Lisensi Dokumen:

 Copyright � 2009 IlmuKomputer.Org

 Seluruh dokumen di IlmuKomputer.Org dapat digunakan, dimodifikasi dan disebarkan
 secara bebas untuk tujuan bukan komersial (nonprofit), dengan syarat tidak meng-
 hapus atau merubah atribut penulis dan pernyataan copyright yang disertakan dalam
 setiap dokumen. Tidak diperbolehkan melakukan penulisan ulang, kecuali mendapat
 kan ijin terlebih dahulu dari IlmuKomputer.Org.
