ENGLISH:

Setup1.exe is the file that Visual Basic uses to make the installation program for any application.
This setup1.exe is modified, so it has a skin and it automatically switches the language according to the user language selected in the PC where the setup process is taking place.
The languages supported are: English, Spanish, French and Italian.

In order to use this file, you must do the following:
Go to the folder where Visual Basic 6.0 is installed, and find the folder where the setup wizard is.

For example, it could be: 
C:\Program files\Microsoft Visual Studio\VB98\Wizards\PDWizard

There you will find a file setup1.exe, rename it to something else.
The uncompress the file setup1.zip that you have downloaded from here.
Copy setup1.exe in the setup wizard directory.

Every time you will make a package with the Visual Basic 6.0 setup wizard it will be made with the new setup program. 
If later you want to go back and wish to use the default VB6 setup program, then delete or rename setup1.exe and name to setup1.exe the default VB6 file.
..............................................................


The files included in this package:

1) this file Readme.txt
2) setup1.exe (program file)
3) web-site.url (link to Web site www.visual-basic.com.ar)

Web site: www.visual-basic.com.ar
Author: Javier Balkenende


_________________________________________________________________________________________________

ESPA�OL:

Setup1.exe es el archivo que usa Visual Basic para hacer el programa de instalaci�n de cualquier aplicaci�n.
Este setup1.exe est� modificado, de modo que tiene un skin y autom�ticamente selecciona el idioma de acuerdo con el idioma seleccionado por el usuario en la PC donde se efect�a la instalaci�n.
Los idiomas que soporta son: Espa�ol, Ingl�s, Franc�s e Italiano.

A los efectos de usar este programa de instalaci�n debe hacer lo siguiente:
Dir�jase al directorio donde est� instalado Visual Basic 6.0, y en ubique la carpeta donde est� el asistente de instalaci�n.

Por ejemplo es probable que sea: 
C:\Archivos de programa\Microsoft Visual Studio\VB98\Wizards\PDWizard

All� va a encontrar un archivo que es setup1.exe, ren�mbrelo.
Luego descomprima el archivo setup1.zip que ha bajado desde aqu�.
Copie setup1.exe en el directorio mencionado.

Cada vez que genere un paquete con el asistente de instalaci�n de Visual Basic 6.0 lo har� con el nuevo archivo de setup. 
Si luego desea volver a usar el archivo original de instalaci�n, entonces borre o renombre setup1.exe y tambi�n vuelva a nombrar correctamente el archivo original.
..........................................................................


Los archivos incluidos en este paquete son:

1) este archivo Readme.txt
2) setup1.exe (archivo del programa)
3) web-site.url (acceso directo al Sitio web www.visual-basic.com.ar)

Sitio web: www.visual-basic.com.ar
Autor: Javier Balkenende
